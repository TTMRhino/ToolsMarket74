<?php foreach($data as $val):?>
    <option value="<?= $val->id ?>"> <?= $val->title ?> </option>
<?php endforeach ?>